<section style="background:black;">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 col-6">
                <div class="logo">
                    <img src="images/png/logo-no-background.png" width="100%" alt="">
                </div>
            </div>
            <div class="col-md-9 top-menu">
                <div class="pages">
                    <ul>
                        <li>Home</li>
                        <li>About</li>
                        <li>Services</li>
                        <li>Contact</li>
                        <li>Login</li>
                    </ul>
                </div>
            </div>

            <div class="col-md-1 col-6 sidebar-btn">
                <div class="sidebar-icon">
                    <!-- <button onclick="closeRightMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button> -->
                    <div class="w3-teal">
                        <button class="w3-button w3-teal w3-xlarge w3-right" onclick="openRightMenu()">&#9776;</button>
                    </div>
                    <div class="w3-sidebar w3-bar-block w3-card w3-animate-right" style="display:none;right:0;"
                        id="rightMenu">
                        <button onclick="closeRightMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
                        <a href="#" class="w3-bar-item w3-button">Link 1</a>
                        <a href="#" class="w3-bar-item w3-button">Link 2</a>
                        <a href="#" class="w3-bar-item w3-button">Link 3</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- <div class="w3-sidebar w3-bar-block w3-card w3-animate-right" style="display:none;right:0;" id="rightMenu">
    <button onclick="closeRightMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
    <a href="#" class="w3-bar-item w3-button">Link 1</a>
    <a href="#" class="w3-bar-item w3-button">Link 2</a>
    <a href="#" class="w3-bar-item w3-button">Link 3</a>
</div>

<div class="w3-teal">
    <button class="w3-button w3-teal w3-xlarge w3-right" onclick="openRightMenu()">&#9776;</button>
</div> -->